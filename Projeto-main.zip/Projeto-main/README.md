Fiz este pequeno projeto pessoal apenas para fixar meu aprendizado, não é nada demais nem muito avançado.
